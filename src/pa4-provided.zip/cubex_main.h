#ifndef _CUBEX_MAIN
#define _CUBEX_MAIN

void cubex_main();


#endif
