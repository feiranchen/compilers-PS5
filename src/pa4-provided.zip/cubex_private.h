#ifndef _CUBEX_PRIVATE
#define _CUBEX_PRIVATE

void initialize(int argc, char** argv);


#endif
